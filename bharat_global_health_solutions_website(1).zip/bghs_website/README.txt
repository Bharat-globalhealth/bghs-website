BHARAT GLOBAL HEALTH SOLUTIONS WEBSITE

Files:
- index.html: complete responsive one-page company website.

Preview:
Open index.html in a web browser.

Publish free with GitHub Pages:
1. Sign in or create an account at https://github.com
2. Create a new PUBLIC repository named bghs-website.
3. Upload index.html from this folder to the repository root (top level).
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for the Pages deployment to complete. GitHub shows the published URL in Settings > Pages.

Important:
- The free URL will be https://YOUR-GITHUB-USERNAME.github.io/bghs-website/ (replace with your username).
- bharatglobalhealthsolutions.com is not configured because the domain has not been purchased.
- This is a static informational site. The email links open the visitor's email app; there is no web form backend.
- Do not publish sensitive data in the repository.
